import s from './Gallery.module.css'
import puppy1 from '../Img/puppy1.jpg'

const Products = () => {
    return(
        <section className={s.products}>
            <div className={s.box}>
                <img src={puppy1} className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:1</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:2</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:3</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:4</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:5</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:6</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:7</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:8</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:9</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:10</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:11</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:12</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:13</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:14</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:15</p>
            </div>
            <div className={s.box}>
                <img src="" className={s.img} alt="" />
                <h3>Cute puppy!</h3>
                <p>breed:</p>
                <p>age</p>
                <p>order number:16</p>
            </div>
        </section>
    )
}

export default Products